#ifdef _WIN32
#include <Windows.h>
#endif // _WIN32

#include <iostream>
#include <fstream>
#include <vector>
#include <array>
#include <sstream>
#include <string>



int main()
{
#ifdef _WIN32
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
#endif // _WIN32

    // Demander le fichier .pgm
    std::string nomFichier;
    std::cout << "Ecrivez le nom du fichier PGM : ";
    std::getline(std::cin, nomFichier);

    std::ifstream fichier(nomFichier, std::ios_base::binary);
    if (!fichier.is_open())
    {
        std::cerr << "Probl�me d'ouverture du fichier '" << nomFichier << "'. \n";
        return 0;
    }



    // Demander le fichier de palette
    std::string nomFichierPalette;
    std::cout << "Ecrivez le nom du fichier de palette : \n"
        << "- palette.txt  \n"
        << "- palette2.txt \n"
        << "- palette2UTF8.txt \n"
        << "- paletteUTF8.txt \n";
    std::getline(std::cin, nomFichierPalette);

    // Ouverture fichier palette
    std::ifstream fichierPalette(nomFichierPalette);
    if (!fichierPalette.is_open())
    {
        std::cerr << "Probl�me d'ouverture du fichier de palette '" << nomFichierPalette << "'. \n";
        return 0;
    }

    // Charger la palette
    std::vector<std::string> palette;
    std::string lignePalette;

    // copie des donn�es de la palette dans un tableau (palette)
    while (!fichierPalette.eof())
    {
        std::getline(fichierPalette, lignePalette);
        palette.push_back(lignePalette);
    }

    // Demander le fichier de sortie
    std::string nomFichierSortie;
    std::cout << "Ecrivez le nom du fichier de sortie : ";
    std::cin >> nomFichierSortie;

    std::ofstream out(nomFichierSortie);
    if (!out.is_open())
    {
        std::cerr << "Erreur � la cr�ation du nouveau fichier.";
        return 0;
    }
    else
        std::cout << "Le fichier a �t� cr�� avec succ�s.\n";



    // Lecture ent�te
    std::string ligne;
    std::getline(fichier, ligne); // P5
    std::getline(fichier, ligne); // Commentaire
    std::getline(fichier, ligne); // Dimensions
    std::stringstream ssDimensions(ligne);
    int largeur;
    int hauteur;
    ssDimensions >> largeur;
    ssDimensions >> hauteur;

    std::getline(fichier, ligne); // Max valeur (255)

    // Lire les donnees binaire
    std::vector<char> donnees(largeur * hauteur);
    fichier.read(donnees.data(), donnees.size());

    // Conversion 
    std::vector<std::string> donneesDecoder(largeur * hauteur);
    int niveaux = 256 / palette.size(); // Mise en proportion des �chelle

    // Boucle de convertion de donn�es
    for (size_t i = 0; i < donnees.size(); ++i)
    {
        int valeurPixel = static_cast<unsigned char>(donnees[i]);
        int indexPalette = valeurPixel / niveaux;

        if (indexPalette >= palette.size())
        {
            indexPalette = palette.size() - 1; // Pour g�rer les valeurs maximales
        }

        donneesDecoder[i] = palette[indexPalette]; // Premier caract�re de la ligne de palette
        /*std::cout << palette[indexPalette][0] << '\n';*/
    }

    // �crire dans le fichier de sortie
    for (int i = 0; i < hauteur; ++i)
    {
        for (int j = 0; j < largeur; ++j)
        {
            out << donneesDecoder[i * largeur + j];
            // i * largeur : Saute tous les �l�ments des lignes pr�c�dentes pour arriver � la ligne i
            // + j : Acc�de � la colonne j dans la ligne actuelle
        }
        out << "\n";
    }

    std::cout << "-- Copie termin�e --\n";
    return 0;
}
